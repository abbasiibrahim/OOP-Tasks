#include <iostream>
using namespace std;

// Function Template
template <typename T>
T findMin(T a, T b)
{
    if
(a<b)
	return a;
	else
	b;
}

int main()
{
    cout << "Integer " << findMin(10, 20) << endl;
    cout << "Double " << findMin(5.5, 2.3) << endl;
    cout << "Character " << findMin('A', 'Z') << endl;

    return 0;
}